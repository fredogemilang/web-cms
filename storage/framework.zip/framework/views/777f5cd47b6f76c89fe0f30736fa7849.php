<ul class="space-y-1">
    <!-- Main Section -->
    <li class="px-4 pt-4 pb-2">
        <span class="text-[10px] font-bold text-[#6F767E] uppercase tracking-widest sidebar-text">Main</span>
    </li>
    <li>
        <a wire:navigate class="flex items-center gap-3 rounded-xl px-4 py-3 transition-all duration-200 nav-item overflow-hidden <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC]' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>"
            href="<?php echo e(route('admin.dashboard')); ?>">
            <span class="material-symbols-outlined shrink-0">dashboard</span>
            <span class="font-semibold text-[15px] sidebar-text">Dashboard</span>
        </a>
    </li>

    <!-- Content Section -->
    <li class="px-4 pt-4 pb-2">
        <span class="text-[10px] font-bold text-[#6F767E] uppercase tracking-widest sidebar-text">Content</span>
    </li>
    <li x-data="{ open: <?php echo e(request()->routeIs('admin.pages.*') ? 'true' : 'false'); ?> }">
        <button
            @click="open = !open; $dispatch('submenu-toggle')"
            class="w-full group flex items-center justify-between rounded-xl px-4 py-3 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 cursor-pointer focus:outline-none nav-item overflow-hidden">
            <div class="flex items-center gap-3">
                <span class="material-symbols-outlined shrink-0">article</span>
                <span class="font-semibold text-[15px] sidebar-text">Pages</span>
            </div>
            <span class="material-symbols-outlined text-xl transition-transform duration-300 expand-icon" :class="{ 'rotate-180': open }">expand_more</span>
        </button>
        <div class="submenu-container overflow-hidden" :style="open ? 'max-height: 200px; opacity: 1' : 'max-height: 0; opacity: 0'">
            <ul class="submenu-list mt-1 space-y-1">
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 hover:bg-white hover:shadow-sm dark:hover:bg-[#272B30] dark:hover:shadow-none <?php echo e(request()->routeIs('admin.pages.index') ? 'text-[#2563EB] font-semibold dark:text-[#FCFCFC] dark:bg-[#272B30]' : 'text-[#6F767E] hover:text-[#111827] dark:hover:text-[#FCFCFC]'); ?>" href="<?php echo e(route('admin.pages.index')); ?>">
                        <span class="text-[14px] font-medium">All Pages</span>
                    </a>
                </li>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 hover:bg-white hover:shadow-sm dark:hover:bg-[#272B30] dark:hover:shadow-none <?php echo e(request()->routeIs('admin.pages.create') ? 'text-[#2563EB] font-semibold dark:text-[#FCFCFC] dark:bg-[#272B30]' : 'text-[#6F767E] hover:text-[#111827] dark:hover:text-[#FCFCFC]'); ?>" href="<?php echo e(route('admin.pages.create')); ?>">
                        <span class="text-[14px] font-medium">Add Page</span>
                    </a>
                </li>
            </ul>
        </div>
    </li>

    
    <?php
        $cpts = \App\Models\CustomPostType::active()->inMenu()->get();
    ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $cpts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
    <?php
        $cptTaxonomies = $cpt->taxonomies();
        $isCptActive = (request()->routeIs('admin.cpt.entries.*') && request()->route('postTypeSlug') === $cpt->slug);
        $isTaxonomyActive = (request()->routeIs('admin.taxonomies.terms.*') && $cptTaxonomies->where('id', request()->route('taxonomy'))->isNotEmpty());
    ?>
    <li x-data="{ open: <?php echo e($isCptActive || $isTaxonomyActive ? 'true' : 'false'); ?> }">
        <button
            @click="open = !open; $dispatch('submenu-toggle')"
            class="w-full group flex items-center justify-between rounded-xl px-4 py-3 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 cursor-pointer focus:outline-none nav-item overflow-hidden">
            <div class="flex items-center gap-3">
                <span class="material-symbols-outlined shrink-0"><?php echo e($cpt->icon ?? 'article'); ?></span>
                <span class="font-semibold text-[15px] sidebar-text"><?php echo e($cpt->plural_label); ?></span>
            </div>
            <span class="material-symbols-outlined text-xl transition-transform duration-300 expand-icon" :class="{ 'rotate-180': open }">expand_more</span>
        </button>
        <div class="submenu-container overflow-hidden" :style="open ? 'max-height: 500px; opacity: 1' : 'max-height: 0; opacity: 0'">
            <ul class="submenu-list mt-1 space-y-1">
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 hover:bg-white hover:shadow-sm dark:hover:bg-[#272B30] dark:hover:shadow-none <?php echo e((request()->routeIs('admin.cpt.entries.index') && request()->route('postTypeSlug') === $cpt->slug) ? 'text-[#2563EB] font-semibold dark:text-[#FCFCFC] dark:bg-[#272B30]' : 'text-[#6F767E] hover:text-[#111827] dark:hover:text-[#FCFCFC]'); ?>" 
                       href="<?php echo e(route('admin.cpt.entries.index', $cpt->slug)); ?>">
                        <span class="text-[14px] font-medium">All <?php echo e($cpt->plural_label); ?></span>
                    </a>
                </li>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 hover:bg-white hover:shadow-sm dark:hover:bg-[#272B30] dark:hover:shadow-none <?php echo e((request()->routeIs('admin.cpt.entries.create') && request()->route('postTypeSlug') === $cpt->slug) ? 'text-[#2563EB] font-semibold dark:text-[#FCFCFC] dark:bg-[#272B30]' : 'text-[#6F767E] hover:text-[#111827] dark:hover:text-[#FCFCFC]'); ?>" 
                       href="<?php echo e(route('admin.cpt.entries.create', $cpt->slug)); ?>">
                        <span class="text-[14px] font-medium">Add <?php echo e($cpt->singular_label); ?></span>
                    </a>
                </li>
                
                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $cptTaxonomies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taxonomy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 hover:bg-white hover:shadow-sm dark:hover:bg-[#272B30] dark:hover:shadow-none <?php echo e((request()->routeIs('admin.taxonomies.terms.*') && request()->route('taxonomy') == $taxonomy->id) ? 'text-[#2563EB] font-semibold dark:text-[#FCFCFC] dark:bg-[#272B30]' : 'text-[#6F767E] hover:text-[#111827] dark:hover:text-[#FCFCFC]'); ?>" 
                       href="<?php echo e(route('admin.taxonomies.terms.index', $taxonomy->id)); ?>">
                        <span class="text-[14px] font-medium"><?php echo e($taxonomy->plural_label); ?></span>
                    </a>
                </li>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </ul>
        </div>
    </li>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('media.view')): ?>
    <li x-data="{ open: <?php echo e(request()->routeIs('admin.media.*') ? 'true' : 'false'); ?> }">
        <button
            @click="open = !open"
            class="w-full group flex items-center justify-between rounded-xl px-4 py-3 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 cursor-pointer focus:outline-none nav-item overflow-hidden">
            <div class="flex items-center gap-3">
                <span class="material-symbols-outlined shrink-0">perm_media</span>
                <span class="font-semibold text-[15px] sidebar-text">Media</span>
            </div>
            <span class="material-symbols-outlined text-xl transition-transform duration-300 expand-icon" :class="{ 'rotate-180': open }">expand_more</span>
        </button>
        <div class="submenu-container overflow-hidden" :style="open ? 'max-height: 200px; opacity: 1' : 'max-height: 0; opacity: 0'">
            <ul class="submenu-list mt-1 space-y-1">
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 <?php echo e(request()->routeIs('admin.media.index') ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC] font-semibold' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>" href="<?php echo e(route('admin.media.index')); ?>">
                        <span class="text-[14px] font-medium">Library</span>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('media.upload')): ?>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 <?php echo e(request()->routeIs('admin.media.create') ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC] font-semibold' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>" href="<?php echo e(route('admin.media.create')); ?>">
                        <span class="text-[14px] font-medium">Add Media</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </li>
    <?php endif; ?>

    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('forms.view')): ?>
    <li x-data="{ open: <?php echo e(request()->routeIs('admin.forms.*') ? 'true' : 'false'); ?> }">
        <button
            @click="open = !open"
            class="w-full group flex items-center justify-between rounded-xl px-4 py-3 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 cursor-pointer focus:outline-none nav-item overflow-hidden">
            <div class="flex items-center gap-3">
                <span class="material-symbols-outlined shrink-0">description</span>
                <span class="font-semibold text-[15px] sidebar-text">Forms</span>
            </div>
            <span class="material-symbols-outlined text-xl transition-transform duration-300 expand-icon" :class="{ 'rotate-180': open }">expand_more</span>
        </button>
        <div class="submenu-container overflow-hidden" :style="open ? 'max-height: 200px; opacity: 1' : 'max-height: 0; opacity: 0'">
            <ul class="submenu-list mt-1 space-y-1">
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 <?php echo e(request()->routeIs('admin.forms.index') ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC] font-semibold' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>" href="<?php echo e(route('admin.forms.index')); ?>">
                        <span class="text-[14px] font-medium">All Forms</span>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('forms.create')): ?>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 <?php echo e(request()->routeIs('admin.forms.create') ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC] font-semibold' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>" href="<?php echo e(route('admin.forms.create')); ?>">
                        <span class="text-[14px] font-medium">Create Form</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </li>
    <?php endif; ?>

    
    <?php
        $pluginMenuEvent = new \App\Events\RenderAdminMenu();
        event($pluginMenuEvent);
        $pluginMenus = collect($pluginMenuEvent->getMenuItems())->filter(fn($item) => str_starts_with($item['source'] ?? '', 'plugin:'));
    ?>
    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pluginMenus->isNotEmpty()): ?>
    <li class="px-4 pt-4 pb-2">
        <span class="text-[10px] font-bold text-[#6F767E] uppercase tracking-widest sidebar-text">Plugins</span>
    </li>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $pluginMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pluginMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($pluginMenu['permission'] ?? '')): ?>
        <li x-data="{ open: <?php echo e(request()->routeIs($pluginMenu['route'] . '*') ? 'true' : 'false'); ?> }">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($pluginMenu['children'])): ?>
                <button
                    @click="open = !open"
                    class="w-full group flex items-center justify-between rounded-xl px-4 py-3 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 cursor-pointer focus:outline-none nav-item overflow-hidden">
                    <div class="flex items-center gap-3">
                        <span class="material-symbols-outlined shrink-0"><?php echo e($pluginMenu['icon'] ?? 'extension'); ?></span>
                        <span class="font-semibold text-[15px] sidebar-text"><?php echo e($pluginMenu['title']); ?></span>
                    </div>
                    <span class="material-symbols-outlined text-xl transition-transform duration-300 expand-icon" :class="{ 'rotate-180': open }">expand_more</span>
                </button>
                <div class="submenu-container overflow-hidden" :style="open ? 'max-height: 300px; opacity: 1' : 'max-height: 0; opacity: 0'">
                    <ul class="submenu-list mt-1 space-y-1">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $pluginMenu['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($child['permission'] ?? '')): ?>
                            <li class="relative pl-6 py-1">
                                <div class="submenu-item-connector"></div>
                                <a class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 <?php echo e(request()->routeIs($child['route']) ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC] font-semibold' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>" 
                                   href="<?php echo e($child['url'] ?? '#'); ?>">
                                    <span class="text-[14px] font-medium"><?php echo e($child['title']); ?></span>
                                </a>
                            </li>
                            <?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </ul>
                </div>
            <?php else: ?>
                <a class="flex items-center gap-3 rounded-xl px-4 py-3 transition-all duration-200 nav-item overflow-hidden <?php echo e(request()->routeIs($pluginMenu['route']) ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC]' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>"
                    href="<?php echo e($pluginMenu['url'] ?? '#'); ?>">
                    <span class="material-symbols-outlined shrink-0"><?php echo e($pluginMenu['icon'] ?? 'extension'); ?></span>
                    <span class="font-semibold text-[15px] sidebar-text"><?php echo e($pluginMenu['title']); ?></span>
                </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </li>
        <?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <!-- Management Section -->
    <li class="px-4 pt-4 pb-2">
        <span class="text-[10px] font-bold text-[#6F767E] uppercase tracking-widest sidebar-text">Management</span>
    </li>
    <!-- CPT Menu -->
    <li x-data="{ open: <?php echo e(request()->routeIs('admin.cpt.index') || request()->routeIs('admin.cpt.create') || request()->routeIs('admin.cpt.edit') || (request()->routeIs('admin.taxonomies.*') && !request()->routeIs('admin.taxonomies.terms.*')) ? 'true' : 'false'); ?> }">
        <button
            @click="open = !open"
            class="w-full group flex items-center justify-between rounded-xl px-4 py-3 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 cursor-pointer focus:outline-none nav-item overflow-hidden">
            <div class="flex items-center gap-3">
                <span class="material-symbols-outlined shrink-0">layers</span>
                <span class="font-semibold text-[15px] sidebar-text">CPT</span>
            </div>
            <span class="material-symbols-outlined text-xl transition-transform duration-300 expand-icon" :class="{ 'rotate-180': open }">expand_more</span>
        </button>
        <div class="submenu-container overflow-hidden" :style="open ? 'max-height: 200px; opacity: 1' : 'max-height: 0; opacity: 0'">
            <ul class="submenu-list mt-1 space-y-1">
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 <?php echo e(request()->routeIs('admin.cpt.*') ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC] font-semibold' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>" href="<?php echo e(route('admin.cpt.index')); ?>">
                        <span class="text-[14px] font-medium">Post Types</span>
                    </a>
                </li>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 <?php echo e((request()->routeIs('admin.taxonomies.*') && !request()->routeIs('admin.taxonomies.terms.*')) ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC] font-semibold' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>" href="<?php echo e(route('admin.taxonomies.index')); ?>">
                        <span class="text-[14px] font-medium">Taxonomies</span>
                    </a>
                </li>
            </ul>
        </div>
    </li>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['users.view', 'users.create', 'menus.view'])): ?>
    <li x-data="{ open: <?php echo e(request()->routeIs('admin.users.*') || request()->routeIs('admin.profile.*') || request()->routeIs('admin.role-permission.*') || request()->routeIs('admin.roles.*') || request()->routeIs('admin.menus.*') ? 'true' : 'false'); ?> }">
        <button
            @click="open = !open"
            class="w-full group flex items-center justify-between rounded-xl px-4 py-3 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 cursor-pointer focus:outline-none nav-item overflow-hidden">
            <div class="flex items-center gap-3">
                <span class="material-symbols-outlined shrink-0">group</span>
                <span class="font-semibold text-[15px] sidebar-text">User</span>
            </div>
            <span class="material-symbols-outlined text-xl transition-transform duration-300 expand-icon" :class="{ 'rotate-180': open }">expand_more</span>
        </button>
        <div class="submenu-container overflow-hidden" :style="open ? 'max-height: 350px; opacity: 1' : 'max-height: 0; opacity: 0'">
            <ul class="submenu-list mt-1 space-y-1">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.view')): ?>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 <?php echo e(request()->routeIs('admin.users.index') ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC] font-semibold' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>" 
                       href="<?php echo e(route('admin.users.index')); ?>">
                        <span class="text-[14px] font-medium">All Users</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.create')): ?>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 <?php echo e(request()->routeIs('admin.users.create') ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC] font-semibold' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>" 
                       href="<?php echo e(route('admin.users.create')); ?>">
                        <span class="text-[14px] font-medium">Add User</span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 <?php echo e(request()->routeIs('admin.profile.*') ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC] font-semibold' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>" 
                       href="<?php echo e(route('admin.profile.index')); ?>">
                        <span class="text-[14px] font-medium">Profile</span>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.view')): ?>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 <?php echo e(request()->routeIs('admin.role-permission.*') || request()->routeIs('admin.roles.*') ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC] font-semibold' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>" 
                       href="<?php echo e(route('admin.role-permission.index')); ?>">
                        <span class="text-[14px] font-medium">Role & Permission</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menus.view')): ?>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 <?php echo e(request()->routeIs('admin.menus.*') ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC] font-semibold' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>" 
                       href="<?php echo e(route('admin.menus.index')); ?>">
                        <span class="text-[14px] font-medium">Menu Access</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </li>
    <?php endif; ?>

    <!-- System Section -->
    <li class="px-4 pt-4 pb-2">
        <span class="text-[10px] font-bold text-[#6F767E] uppercase tracking-widest sidebar-text">System</span>
    </li>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plugins.view')): ?>
    <li>
        <a wire:navigate class="flex items-center gap-3 rounded-xl px-4 py-3 transition-all duration-200 nav-item overflow-hidden <?php echo e(request()->routeIs('admin.plugins.*') ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC]' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>"
            href="<?php echo e(route('admin.plugins.index')); ?>">
            <span class="material-symbols-outlined shrink-0">extension</span>
            <span class="font-semibold text-[15px] sidebar-text">Plugins</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('themes.view')): ?>
    <li x-data="{ open: <?php echo e(request()->routeIs('admin.themes.*') ? 'true' : 'false'); ?> }">
        <button
            @click="open = !open"
            class="w-full group flex items-center justify-between rounded-xl px-4 py-3 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 cursor-pointer focus:outline-none nav-item overflow-hidden">
            <div class="flex items-center gap-3">
                <span class="material-symbols-outlined shrink-0">palette</span>
                <span class="font-semibold text-[15px] sidebar-text">Appearance</span>
            </div>
            <span class="material-symbols-outlined text-xl transition-transform duration-300 expand-icon" :class="{ 'rotate-180': open }">expand_more</span>
        </button>
        <div class="submenu-container overflow-hidden" :style="open ? 'max-height: 200px; opacity: 1' : 'max-height: 0; opacity: 0'">
            <ul class="submenu-list mt-1 space-y-1">
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a wire:navigate class="flex items-center rounded-xl px-4 py-2.5 transition-all duration-200 relative z-10 <?php echo e(request()->routeIs('admin.themes.*') ? 'bg-blue-100 text-[#2563EB] dark:bg-[#272B30] dark:text-[#FCFCFC] font-semibold' : 'text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none'); ?>"
                       href="<?php echo e(route('admin.themes.index')); ?>">
                        <span class="text-[14px] font-medium">Themes</span>
                    </a>
                </li>
            </ul>
        </div>
    </li>
    <?php endif; ?>
    <li x-data="{ open: false }">
        <button
            @click="open = !open"
            class="w-full group flex items-center justify-between rounded-xl px-4 py-3 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 cursor-pointer focus:outline-none nav-item overflow-hidden">
            <div class="flex items-center gap-3">
                <span class="material-symbols-outlined shrink-0">settings</span>
                <span class="font-semibold text-[15px] sidebar-text">Settings</span>
            </div>
            <span class="material-symbols-outlined text-xl transition-transform duration-300 expand-icon" :class="{ 'rotate-180': open }">expand_more</span>
        </button>
        <div class="submenu-container overflow-hidden" :style="open ? 'max-height: 400px; opacity: 1' : 'max-height: 0; opacity: 0'">
            <ul class="submenu-list mt-1 space-y-1">
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a class="flex items-center rounded-xl px-4 py-2.5 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 relative z-10" href="#">
                        <span class="text-[14px] font-medium">General</span>
                    </a>
                </li>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a class="flex items-center rounded-xl px-4 py-2.5 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 relative z-10" href="#">
                        <span class="text-[14px] font-medium">Brevo API</span>
                    </a>
                </li>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a class="flex items-center rounded-xl px-4 py-2.5 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 relative z-10" href="#">
                        <span class="text-[14px] font-medium">Languages</span>
                    </a>
                </li>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a class="flex items-center rounded-xl px-4 py-2.5 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 relative z-10" href="#">
                        <span class="text-[14px] font-medium">SEO</span>
                    </a>
                </li>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a class="flex items-center rounded-xl px-4 py-2.5 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 relative z-10" href="#">
                        <span class="text-[14px] font-medium">Redirect</span>
                    </a>
                </li>
            </ul>
        </div>
    </li>
    
    <!-- Litespeed Cache Menu -->
    <li x-data="{ open: false }">
        <button
            @click="open = !open"
            class="w-full group flex items-center justify-between rounded-xl px-4 py-3 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 cursor-pointer focus:outline-none nav-item overflow-hidden">
            <div class="flex items-center gap-3">
                <span class="material-symbols-outlined shrink-0">bolt</span>
                <span class="font-semibold text-[15px] sidebar-text">Litespeed Cache</span>
            </div>
            <span class="material-symbols-outlined text-xl transition-transform duration-300 expand-icon" :class="{ 'rotate-180': open }">expand_more</span>
        </button>
        <div class="submenu-container overflow-hidden" :style="open ? 'max-height: 300px; opacity: 1' : 'max-height: 0; opacity: 0'">
            <ul class="submenu-list mt-1 space-y-1">
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a class="flex items-center rounded-xl px-4 py-2.5 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 relative z-10" href="#">
                        <span class="text-[14px] font-medium">Cache</span>
                    </a>
                </li>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a class="flex items-center rounded-xl px-4 py-2.5 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 relative z-10" href="#">
                        <span class="text-[14px] font-medium">CDN</span>
                    </a>
                </li>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a class="flex items-center rounded-xl px-4 py-2.5 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 relative z-10" href="#">
                        <span class="text-[14px] font-medium">Image Optimization</span>
                    </a>
                </li>
                <li class="relative pl-6 py-1">
                    <div class="submenu-item-connector"></div>
                    <a class="flex items-center rounded-xl px-4 py-2.5 text-[#6F767E] hover:text-[#111827] hover:bg-white hover:shadow-sm dark:hover:text-[#FCFCFC] dark:hover:bg-[#272B30] dark:hover:shadow-none transition-all duration-200 relative z-10" href="#">
                        <span class="text-[14px] font-medium">Page Optimization</span>
                    </a>
                </li>
            </ul>
        </div>
    </li>
</ul>
<?php /**PATH C:\laragon\www\web-cms\resources\views/components/admin/sidebar-new.blade.php ENDPATH**/ ?>