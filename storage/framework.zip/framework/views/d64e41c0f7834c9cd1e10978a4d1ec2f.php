<div>
    <div class="container" id="article-list-anchor">
        <!-- Tabs / Filter -->
        <div class="article-filter-nav mb-5">
            <a href="#" wire:click.prevent="setCategory('')" class="article-filter-link <?php echo e($category === '' ? 'active' : ''); ?>">All</a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
            <a href="#" wire:click.prevent="setCategory('<?php echo e($cat->slug); ?>')" class="article-filter-link <?php echo e($category === $cat->slug ? 'active' : ''); ?>"><?php echo e($cat->name); ?></a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>

        <!-- Grid of Articles -->
        <div class="row g-4 position-relative">
            <!-- Loading Indicator -->
            <div wire:loading.flex class="position-absolute w-100 h-100 top-0 start-0 bg-white bg-opacity-75 justify-content-center align-items-center" style="z-index: 10;">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
            <div class="col-md-6 col-lg-4" <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processElementKey('post-{{ $post->id }}', get_defined_vars()); ?>wire:key="post-<?php echo e($post->id); ?>">
                <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="text-decoration-none h-100 d-block">
                    <div class="article-card h-100 d-flex flex-column bg-white rounded-4 overflow-hidden shadow-sm">
                        <div class="article-banner position-relative">
                            <?php
                                $postImg = $post->featured_image;
                                if ($postImg && !str_starts_with($postImg, 'http')) {
                                    $postImg = asset('storage/' . $postImg);
                                }
                            ?>
                            <img src="<?php echo e($postImg ?: '/storage/media/default-blog-iccomjpg-1770368714-AYUyHkb8.webp'); ?>"
                                class="img-fluid w-100 h-100 object-fit-cover" alt="<?php echo e($post->title); ?>">
                        </div>
                        <div class="card-body p-4 flex-grow-1 d-flex flex-column justify-content-center">
                            <p class="small text-muted fw-semibold mb-2"><?php echo e($post->author ? $post->author->name : 'Admin'); ?> | <?php echo e($post->published_at ? $post->published_at->format('M d, Y') : $post->created_at->format('M d, Y')); ?></p>
                            <h4 class="fw-bold mb-0 text-dark"><?php echo e(Str::limit($post->title, 50)); ?></h4>
                            <p class="text-muted mt-2 mb-0 small"><?php echo e(Str::limit(strip_tags($post->content), 100)); ?></p>
                        </div>
                    </div>
                </a>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <div class="col-12 text-center py-5">
                <h4 class="text-muted">No articles found.</h4>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <!-- Pagination -->
        <div class="mt-5 d-flex justify-content-center">
            <?php echo e($posts->links('posts::pagination.custom')); ?>

        </div>
    </div>
    
    <script>
        document.addEventListener('livewire:initialized', () => {
           window.Livewire.find('<?php echo e($_instance->getId()); ?>').on('scroll-to-top', () => {
                const element = document.getElementById('article-list-anchor');
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth' });
                }
           });
           
           window.Livewire.find('<?php echo e($_instance->getId()); ?>').on('update-url', (event) => {
                history.pushState({}, '', event.url);
           });
        });
    </script>
</div>
<?php /**PATH C:\laragon\www\web-cms\plugins\posts\src\Providers/../../resources/views/livewire/blog-list.blade.php ENDPATH**/ ?>